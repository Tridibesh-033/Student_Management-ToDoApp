from django.shortcuts import redirect, render
from my_app.models import Student



# Home Page View

def indexPage(request):
    stu=Student.objects.all()

    context={
        'stu':stu,
    }

    return render(request,'index.html',context)


# Create your views here.



def add(request):
    if request.method == "POST":
        new_name=request.POST.get('name')
        new_email=request.POST.get('email')
        new_phone=request.POST.get('phone')

    stu=Student(
        name=new_name,
        email=new_email,
        phone=new_phone,
    )
    stu.save()
    return redirect('index')
  

def edit(request):
    stu=Student.objects.all()

    context={
        'stu':stu,
    }

    return redirect(request,'index.html',context)

def update(request,id):
    if request.method == "POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')

    stu=Student(
        id=id,
        name=name,
        email=email,
        phone=phone,
    )
    stu.save()
    return redirect('index')

def delete(request,id):
    stu=Student.objects.filter(id=id).delete()

    context={
        'stu':stu,
    }
        

    return redirect('index')